import React from 'react';
import './ChooseNumber.css';
import {connect} from 'react-redux';

const ChooseNumber = ({onInputChange, onChooseClickR, fewR, manyR}) => {
  const fewClasses = fewR ? 'BSCalc__info' : 'BSCalc__info none';
  const manyClasses = manyR ? 'BSCalc__info' : 'BSCalc__info none';

  return (
    <section className='BSCalc'>
      <span id='few' className={fewClasses}>Мало!</span>
      <input onChange={onInputChange} className='BSCalc__input' type='number' min='1' max='100' step='1' placeholder='0' />
      <button onClick={onChooseClickR} className='BSCalc__calc'>Проверить!</button>
      <span id='many' className={manyClasses}>Много!</span>
    </section>
  )
}

// ----------------ACTIONS:
let increaseCount = {type: 'addCount'};

function mapStateToProps(state) {
  return {
    fewR: state.few,
    manyR: state.many,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    onChooseClickR: function() {
      return dispatch(increaseCount)
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ChooseNumber);